JoyRaj Text File Encryption Program v2.17.7.14 Source Code Readme
_______________________________________________________________________

This zipped file contains the code, skins, sample background images and program icons packed into a single archive. Please do not change the name and extension of any file in this archive as it may cause compiling errors. The source code is written in JRCC language and you need JoyRaj Code Compiler to compile the codes.

Original Size of this text file: 642 bytes. 
Any change in this size indicates that this file may have been changed by some unauthorised person.

JoyRaj
joydeep19.webs.com